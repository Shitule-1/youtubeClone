const express=require("express")
const app=express()
const cookieParser=require('cookie-parser')
var port=4000
app.use(express.json())
app.use(cookieParser())
require('./Connection/conn')
const cors=require('cors')

const AuthRoutes=require("./Routes/user")
const VideoRoutes=require('./Routes/video')
const CommentRoutes=require('./Routes/comment')

app.use(cors({
    origin:"http://localhost:5173", //our react project url 
    credentials:true
}))


app.use('/auth',AuthRoutes)
app.use('/api',VideoRoutes)
 app.use('/commentapi',CommentRoutes)

app.listen(port,()=>{
    console.log('server is running on port',port)
})
