const User=require("../Modals/user")
const bcrypt=require("bcryptjs")
const jwt=require("jsonwebtoken")

const cookieOptions={
  httpOnly:true,
  secure:false ,//set true in production
  sameSite:'Lax'
}

exports.signUp= async (req,res)=>{
    //console.log("in signup funtion")  // to check our api is calling or not 
  try {
    const {channelName,userName,about,profilePic,password}=req.body
      // console.log(channelName) 
      const isExist=await User.findOne({userName})
     // console.log(isExist) // if username not in presnet in realtive collection then it console nuul 
      if (isExist) {
        res.status(400).json({error:"username Already Exist"})
      } else {
        let updatedPass=await bcrypt.hash(password,10)
      const user=new User({channelName,userName,about,profilePic,password:updatedPass})
      await user.save()
      res.status(201).json({message:"user register successfully ",success:"yes",data:user})
      }
      
} catch (error) {
    console.log(error)
    res.status(500).json({error:"server error"})
  }
}


//signin 

exports.signIn= async (req,res)=>{
  try {
    const {userName,password}=req.body
    const user=await User.findOne({userName})
    if(user && await bcrypt.compare(password,user.password)){
        const token=jwt.sign({userId:user._id},'Its_My_Secret_Key',)
        res.cookie('token',token,cookieOptions)
    console.log(token) // you can see token on cosole when you press login
        res.json({message:"login successfully",success:"true",token,user})
    }
    else{
      res.status(400).json({error:"invalid username(credentials)"})
    }
  } catch (error) {
    res.status(500).json({error:"server error"})
     
  }
}

//logout
exports.logout=async(req,res)=>{
  res.clearCookie('token',cookieOptions).json({message:"logged out successfully"})

}