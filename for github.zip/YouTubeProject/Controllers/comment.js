const Comment=require('../Modals/comment')


exports.addComment=async (req,res)=>{
    try {
        //console.log(req.user)
       let {video,message}=req.body
       const comment= new Comment({user:req.user._id,video,message})
           await comment.save()
           res.status(201).json(
            {message:"success",comment})
        
        } catch (error) {
        console.log(error)
        res.status(500).json({error:"srever error"})
    }
}

exports.getCommentByVideoId= async (req,res)=>{
    try {
        // console.log(req.params)
  let {videoid}=req.params
   const comments=await Comment.find({video:videoid}).populate('user','channelName profilePic userName createdAt');
   
   res.status(201).json(
    {message:"success",comments})

    } catch (error) {
        console.log(error)
        res.status(500).json({error:"srever error"})
    }
}