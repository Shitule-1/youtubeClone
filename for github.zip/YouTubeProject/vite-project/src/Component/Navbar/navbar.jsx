import React, { useEffect, useState } from "react";
import "./navbar.css"
import MenuIcon from '@mui/icons-material/Menu';
import YouTubeIcon from '@mui/icons-material/YouTube';
import SearchIcon from '@mui/icons-material/Search';
import KeyboardVoiceIcon from '@mui/icons-material/KeyboardVoice';
import VideoCallIcon from '@mui/icons-material/VideoCall';
import NotificationsActiveIcon from '@mui/icons-material/NotificationsActive';
import PersonIcon  from '@mui/icons-material/Person';  
import { Link,useNavigate } from "react-router-dom";
import axios from "axios";
import Login from "../Login/login";
const Navbar = ({setSideNavbarFunc,sideNavbar}) => {
  const [userPic,setUserPic] = useState("data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAJQAnAMBIgACEQEDEQH/xAAbAAEAAgMBAQAAAAAAAAAAAAAAAQUDBAYCB//EADYQAAICAQEGBAIJAwUAAAAAAAABAgMEEQUSITFBURMiYXEUUjJCgZGhwdHw8YKS4SMzNFNy/8QAFgEBAQEAAAAAAAAAAAAAAAAAAAEC/8QAFhEBAQEAAAAAAAAAAAAAAAAAABEB/9oADAMBAAIRAxEAPwD7KAAAAAAAAAAABOj7AQCeRAAAAAAAAAAlEEoCAAAAAAAADQzNqVUNwrXiWLs+CNbaue990Y8tEuE5Lh9iKkuI27do5Vr42uC7Q4Gu7bJPV2Tb9ZM8Aoy15N9f0LrF/U2jex9s2Q0WRBWR+aK0aKwBHVUX15Fe/TNSj+K9zIctj5FmParK5aPquj9zpMXIhlUq2HXg12ZlplAAAAACUQSgIAAAAADV2nk/DYzlF+eXlj79zaKTb1m9kV19IR109X/CArAAaZAAAAAA3dlZHgZMU35LPK/fozSAHXAx49ni49dvzxTfuZDLQAABKIJQEAAAAABz+2P+fPX5UdAUe3a93Jrs6Thp9q/lFxNVoAKgAAAAAAB8gOl2Zr8BTr2Nkx41fg49VT5xik/fqZDLQAABKIJQEAAAAABqbUxviMRqK88HvR9e6NsAciC12tgOEpZFC8r4ziunr7FUaQAAQAAA3NlY/j5UdV5IeaX5GvRRZkWqupat/cvVnSYePDFpVcPeUu7JVZgARQAACUQSgIAAAAACSG0k22kktW2yry9rwjvQxlvP52uH2dwLTXsV2Zsmu1udDVdj4tfVb/Ir6dp5MLlKdjnHXjHRfgdBXONlcZ1vWLWqZUc3dgZNL81UpesOKNdpp6STT7M67kNX3YpHJ102WNKuucm+0Wb2Psi6bTuarj25tl9q+5ApGLHx6saG5VFJPm+rMpXbVz3jpVUvSx8W/lX6mhj7Vyav9x+LHtLn95FdADBi5dOVHWp8UuMHzRnAAAASiCUBAAAHi22FNcrLZbsY8z1OUYRc5vSMVq2c5n5s8u3XVqEXpCPp3LBOfnTy5OP0auke/uagAiBuYGfZiPd036nzj29UaYKOox8qnJS8Kab6xfB/cZ9H2ZyGi7GSN90VpG6xLspskK6qbUI702ox7vgVubtautOOK1OfzteVfqUk5Sm9Zycn3k9SBCplKU5SlJtyb1bfUgAo9QlKE1OEnGSeqafEvNnbRWRpVdorejXKX+ShGvqB1wNHZmd8TXuWv/Viv7l3N4yoSiCUBBJBhzb1jY07HzXCK7voBV7aynKfw0dN2P0/V9vsKsmTbk3J6tvVsg1iAACAAAAAAAAAAAAAD3VZKmyNlb0lF6o6bFvjk0Rtj9bmuz6o5Ysdi5Hh3umT8tnL/wBE1V6SiCURQpNvXb1sKI8oLV+75fv1Ltczlcq3xsmyzXVSk9PboXE1iABUAAAAAAAAAAAAAAAACYycZKUeaeqZAA6ui1XUwtX146mRFbsO3exp1/8AXLgvR/tlkjLTHe3GixrmoNr7jlFyQBrE0AAQAAAAAAAAAAAAAAAAAAFpsBv4i1dHBP8AEu0AZaf/2Q==")
  const [navbarModal, setNavbarModal] = useState(false)
  const navigate=useNavigate()
   const [login,setLogin]=useState(false)
const[isLogedIn,setIsLogedIn]=useState(false)

  const handleClickModal=()=>{
    setNavbarModal(prev=>!prev)
  }
const sideNavbarFunc=()=>{
  setSideNavbarFunc(!sideNavbar) 
}

const handleprofile=()=>{
  let userId=localStorage.getItem("userId")

   navigate(`/user/${userId}`)
    setNavbarModal(false)
} 

const onclickOfPopUpOption=(button)=>{
  setNavbarModal(false)
  
  if(button==="login"){
    setLogin(true)
  }
  else{
     localStorage.clear()
     getLogoutFun()
     setTimeout(()=>{
      navigate('/')
      window.location.reload()
     },2000)
  }
}
const getLogoutFun=async()=>{
axios.post('http://loacalhost:4000/auth/logout',{},{withCredentials:true})
.then((res)=>{
  console.log("Logout")
})
.catch(err=>{
  console.log(err)
})
}
const setLoginModal=()=>{
 setLogin(false)
}

 useEffect(()=>{
         let userProfilePic=localStorage.getItem("userProfilePic");
         setIsLogedIn(localStorage.getItem("userId")!==null?true:false )
       if(userProfilePic!==null){
        setUserPic(userProfilePic)
       }
        },[] )

  return (
    <div className="navbar">
      <div className="navbar-left">
        <div className="navbarHamberger" onClick={sideNavbarFunc}>
          <MenuIcon sx={{ color: "white" }} />
        </div>
        <Link to={"/"} className="navbar_youtubeImg">
          <YouTubeIcon sx={{ fontSize: "34px" }} className="navbar_youtubeImg" />
          <div className="navbar_utubeTitle">
            YouTube
          </div >
        </Link>
      </div>
      <div className="navbar-middle">
        <div className="navbar-searchBox">
          <input type="text" placeholder="Search" className="navbar-searchBoxInput" />
          <div className="navbar_searchIconBox"><SearchIcon sx={{ fontSize: "28px", color: "white" }} /></div>
        </div>
        <div className="navbar_mike"><KeyboardVoiceIcon sx={{ color: "white" }} /></div>
      </div>
      <div className="navbar-right">
<Link to={'/78/upload'} >
<VideoCallIcon sx={{ fontSize: "30px", cursor: "pointer", color: 'white' }} />

</Link>

        <NotificationsActiveIcon sx={{ fontSize: "30px", cursor: "pointer", color: 'white' }} />
        <img onClick={handleClickModal} src={userPic} alt="Logo" className="navbar-right-logo" />
        {/* <PersonIcon sx={{fontSize:"30px",cursor:"pointer",color:'white'}}/> */}
        { navbarModal &&
          <div className="navbar-modal">

{           isLogedIn &&  <div className="navbar-modal-option" onClick={handleprofile}>Profile </div>}
 
 {   isLogedIn &&        <div className="navbar-modal-option" onClick={()=>onclickOfPopUpOption("logout")}>Logout</div>}
 
        { !isLogedIn &&   <div className="navbar-modal-option" onClick={()=>onclickOfPopUpOption("login")}>Login</div>}
        
          </div>
        }

      </div>

{
  //  login && "hi " // what are you pass that data shows
  login && <Login setLoginModal={setLoginModal}/>
}
    </div>

  )
}
export default Navbar

