const mongoose=require("mongoose")

mongoose.connect("mongodb://localhost:27017/youtubeBackend")
.then(()=>console.log("Db connection is successfyl!"))
.catch(err=>console.log(err))