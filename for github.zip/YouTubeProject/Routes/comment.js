const express=require("express")
const router=express.Router()
const CommentController=require('../Controllers/comment')
const auth=require('../middleware/authentication')

router.post('/comment',auth,CommentController.addComment)
router.get('/comment/:videoid',CommentController.getCommentByVideoId)

 
module.exports= router